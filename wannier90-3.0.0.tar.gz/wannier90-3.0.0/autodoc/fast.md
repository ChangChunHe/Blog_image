src_dir:          ../src
output_dir:       ./build_fast
media_dir:        ./media
favicon:          ./media/favicon16x16.png
project:          Wannier90
author:           The Wannier90 Developer Group
project_github:   https://github.com/wannier-developers/wannier90
project_website:  http://wannier.org
title:            Wannier90 developer documentation
summary:          Wannier90 is a code that calculates maximally-localised Wannier functions.
display:          public
                  protected
                  private
source:           false
graph:            false
search:           false
license:          by


This is the Wannier90 developer's documentation. It describes the procedures and modules within Wannier90.
