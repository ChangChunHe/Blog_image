The folder 'testcode' includes a checked-out version of 'testcode2' from
https://github.com/jsspencer/testcode
stripped out of the documentation.

This has been retrieved on March 29, 2017
(master branch, from commit 2258047a0d09714898572244f274f8dc47efadf3).

This has been then modified according to the PR https://github.com/jsspencer/testcode/pull/10
(commit 75bd8204a565e0023f515e50fb110b6629d8092b]


