This folder contains make.inc template files that are used by different 
test farms.

Currently included test farms include:

- TravisCI: for the travis-ci tests running at each commit/pull requests
  at https://travis-ci.org/wannier-developers/wannier90

- EPW_testfarm: for the test farm managed by the EPW developers, hosted
  currently at http://129.67.86.21:8010

