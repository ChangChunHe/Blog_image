#!/bin/bash

pip install pre-commit
pre-commit install
